#ifndef MY_VISITOR_H
#define MY_VISITOR_H

#include "demoBaseVisitor.h"

#include "support/Any.h"

// In visitors, YOU have control over where you go and you can choose where by using the visit
// function on other nodes in the parse tree. You'll see some examples here.
class MyVisitor : public demoBaseVisitor {
public:
  // These override the functions declared in demoBaseVisitor which themselves override the
  // functions declared in demoVisitor. The class demoVisitor is pure virtual, if you know java
  // this is equivalent to an interface. It does not implement any functions, only provides
  // declarations. The class demoBaseVisitor extends demoVisitor and provides a default
  // implementation for each function. All it does is visit every token, left to right, in the
  // rule. This is the reason we do not override visitFile (though we could), because all we want
  // to do is visit every list (which it does already). I'll provide an example implementation
  // in the cpp file anyways for the sake of seeing how it would be done.

  // antlrcpp::Any visitFile(demoParser::FileContext *ctx) override;
  antlrcpp::Any visitList(demoParser::ListContext *ctx) override;
  antlrcpp::Any visitListInternal(demoParser::ListInternalContext *ctx) override;

private:
  // This is my current index into the opens/closes
  //size_t or "size type" is an alias for a standard integer type often used
  // for counts and sizes. It's always unsigned and often 64 bits wide.
  size_t index = 0;
};

// ------------
// | Part 2, look at the fist visitor and listner first and understand those before you come here.
// ------------
// Here we'll just try something fun with state, just to see how we might do something like that.
// Why not vary our bracket style based on depth. We'll also reverse all strings, add the count of
// number-like (float or int) variables we've seen to each number-like variable. There's no real
// rhyme or reason, it's just for fun. The functions here will be more sparsely documented.
class MyVisitor2 : public demoBaseVisitor {
public:
  antlrcpp::Any visitFile(demoParser::FileContext *ctx) override;
  antlrcpp::Any visitList(demoParser::ListContext *ctx) override;
  antlrcpp::Any visitListInternal(demoParser::ListInternalContext *ctx) override;

private:
  // This is my current index into the opens/closes arrays.
  // size_t or "size type" is an alias for a standard integer type often used
  // for counts and sizes. It's always unsigned and often 64 bits wide.
  size_t index = 0;

  // How many number-like variables we've seen.
  size_t count = 0;
};

#endif
