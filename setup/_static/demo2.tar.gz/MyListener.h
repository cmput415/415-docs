#ifndef MY_LISTENER_H
#define MY_LISTENER_H

#include "demoBaseListener.h"

#include "support/Any.h"

#include <stack>

// In listeners, ANTLR is driving and you're just along for the ride. You can tell when you enter
// and exit nodes, but you cannot control the direction or order (always depth first, left to
// right according to your grammar).
// A listener is may not ideal for this task, as you'll see. Because I have no context about where
// I am in a list like I do in a visitor (because I'm managing when to change nodes), I need t
// keep extra state in my class. If I was filling a data structure I wouldn't be losing anything,
// but since I'm printing things and want it to be "pretty"... things might get a little different.
// That being said, a lot of the code here is a LOT simpler in some regards.
class MyListener : public demoBaseListener {
public:
  // These override the functions declared in demoBaseListener which themselves override the
  // functions declared in demoListener. The class demoListener is pure virtual, if you know java
  // this is equivalent to an interface. It does not implement any functions, only provides
  // declarations. The class demoBaseListener extends demoListener and provides a default
  // implementation for each function. Currently, these do absolutely nothing (you can check the
  // definitions in baseDemoListener.h if you'd like). This means we only need to implement
  // functions that are useful to us instead of every one of them, even if they would be empty.
  // As well, there are extra functions for before and after every rule, TerminalNodes and
  // ErrorNodes. I've only ever needed the functions for my nodes, but maybe you'll find a use.

  void enterList(demoParser::ListContext *ctx) override;
  void exitList(demoParser::ListContext *ctx) override;
  void enterListInternal(demoParser::ListInternalContext *ctx) override;
  void exitListInternal(demoParser::ListInternalContext *ctx) override;

// This is where I'm going to keep the state things that are necessary for me to "pretty print"
// things.
private:
  // The idea here is that I'll push a counter onto this stack for each new list I enter,
  // decrementing it as I go and eventually, for the last entry, it will be one. I'll also pop
  // when I leave a list. size_t or "size type" is an alias for a standard integer type often used
  // for counts and sizes. It's always unsigned and often 64 bits wide.
  std::stack<size_t *> counts;
};

#endif
