#include "MyVisitor.h"

#include <algorithm>
#include <cassert>
#include <iostream>
#include <string>

// Coming into this function, we don't know if we're the outermost list or an inner list. Does that
// really matter? Fortunately not. We can always just pretend we're the only list and print things
// that matter to us from the context given to us.
antlrcpp::Any MyVisitor::visitList(demoParser::ListContext *ctx) {
  // Well I'm a list and I want to print a list. So let's start with the brackets.
  std::cout << '[';

  // Here we have the option of accessing ctx->listInternal(), which returns a vector of internals,
  // or ctx->listInternal(int), which returns a single internal. I use the first version here
  // because I want to iterate an unknown number. Sometimes, when you know exactly how many are in
  // the vector (2 recursive exprs in an expr?) it makes more sense to index manually.
  // We're using iterators here instead of a traditional for loop. They're a new concept since
  // c++11 that can give a more general access pattern to containers.
  auto internals = ctx->listInternal();
  for (auto it = internals.begin(); it != internals.end(); ++it) {
    // For each internal, we want it to print itself, but we also want to separate each value with
    // a comma. This is where you need to understand your contract with yourself (since we're
    // recursive, what would we print if ended up visiting ourself) and the other things you can
    // potentially visit (if the internal is a float, int, str, what will happen if I visit
    // them?). Here, it's fairly simple: if a list prints itself, we can still follow it with a
    // comma and it remains "well formed", the same goes for the atoms. So let's just simply visit
    // them. Note that we don't return anything interesting, but you can (again, think exprs).

    // Print the internal!
    visit(*it);

    // Now we need to print the comma if this isn't the last...
    if ((it + 1) != internals.end())
      std::cout << ", ";
  }

  // I'm still a list! I need to close this off now.
  std::cout << ']';

  // We don't expect to return anything.
  return nullptr;
}

// Same thing applies as above. You don't know where you are in a list, but you know that you're a
// component. All of our needed context is given in ctx.
antlrcpp::Any MyVisitor::visitListInternal(demoParser::ListInternalContext *ctx) {
  // So we're in a node with tokens that we care about (atoms/leaves) like ints/floats/strings
  // which means we should probably check if we parsed them at all. The easiest thing to do is to
  // just check if the context has one or not. If you call the function that would normally return
  // the token and it returns nullptr, then that option was not parsed.
  // We need to remember our contract with ourselves again here. What did we agree to do before?
  // If print's all we should do, let's take care of that for the atoms...
  if (ctx->INT())
    std::cout << ctx->INT()->getText();
  else if (ctx->FLOAT())
    std::cout << ctx->FLOAT()->getText();
  else if (ctx->STR())
    std::cout << ctx->STR()->getText();
  // This is the recursive section. We're not immediately recursive since visitList wouldn't
  // immediately call itself, but this secondary function does call it. Anyways, again with the
  // contract business. Visiting a list node will call the visitList function, which we've already
  // determined above will print a list appropriately. Therefore, let's just visit it!
  else if (ctx->list())
    visit(ctx->list());
  // This should never happen. Maybe include a useful error message if it does and you'll catch it
  // sooner rather than later.
  else
    assert(false && "List internal was a bad alternative.");

  // We don't expect to return anything.
  return nullptr;
}

// This function is really simple because we don't need to do anything here. We COULD add
// functionality like separating every list here with newlines. We can do that because we know from
// the way we've designed the grammar that every list node here is a "top level" list: there's
// nothing surrounding it.
// antlrcpp::Any MyVisitor::visitFile(demoParser::FileContext *ctx) {
//   for (auto list : ctx->list()) {
//     visit(list);
//     std::cout << '\n';
//   }
//
//   // We don't expect to return anything.
//   return nullptr;
// }

// ------------
// | Part 2, look at the fist visitor and listner first and understand those before you come here.
// ------------
// A list of opening and closing brackets.
static const char opens[4] = {'<', '{', '[', '('};
static const char closes[4] = {'>', '}', ']', ')'};

antlrcpp::Any MyVisitor2::visitList(demoParser::ListContext *ctx) {
  // Print the current version of bracket then increment the index.
  std::cout << opens[index];
  index = (index + 1) % sizeof(opens);

  auto internals = ctx->listInternal();
  for (auto it = internals.begin(); it != internals.end(); ++it) {
    // Print the internal!
    visit(*it);

    // Now we need to print the comma if this isn't the last...
    if ((it + 1) != internals.end())
      std::cout << ", ";
  }

  // Decrement the index then print the version of the bracket.
  index = index == 0 ? sizeof(opens) - 1 : index - 1;
  std::cout << closes[index];

  // We don't expect to return anything.
  return nullptr;
}

antlrcpp::Any MyVisitor2::visitListInternal(demoParser::ListInternalContext *ctx) {
  // We're going to be a bit clever here to keep things in one line. Pre-incrementing (++var) does
  // exactly that, it increments before giving you the value of the variable, likewise for
  // pre-decrement. Post-increment/decrement (var++) will first save a copy of the value, then
  // increment the original value, but return the copy to you so you get the old value.
  if (ctx->INT())
    std::cout << (std::stoi(ctx->INT()->getText()) + count++);
  else if (ctx->FLOAT())
    // Static cast is c++ style casting checked at compile time. We want the result to still be a
    // float.
    std::cout << (std::stof(ctx->FLOAT()->getText()) + static_cast<float>(count++));
  else if (ctx->STR()) {
    std::string str = ctx->STR()->getText();
    std::reverse(str.begin(), str.end());
    std::cout << str;
  }
  else if (ctx->list())
    visit(ctx->list());
  // This should never happen. Maybe include a useful error message if it does and you'll catch it
  // sooner rather than later.
  else
    assert(false && "List internal was a bad alternative.");

  // We don't expect to return anything.
  return nullptr;
}


antlrcpp::Any MyVisitor2::visitFile(demoParser::FileContext *ctx) {
  for (auto list : ctx->list()) {
    visit(list);
    std::cout << '\n';
  }

  // We don't expect to return anything.
  return nullptr;
}
