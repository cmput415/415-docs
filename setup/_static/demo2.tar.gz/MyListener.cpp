#include "MyListener.h"

#include <iostream>
#include <cassert>

// We're entering a list, there's two things we need to do:
// 1. Print the opening square bracket.
// 2. Note the fact that we're entering a list (add a count).
void MyListener::enterList(demoParser::ListContext *ctx) {
  std::cout << '[';

  // Allocate space for a counter, we can't pass the count to the internals so
  // we need to new some space for it.
  size_t *count = new size_t;
  *count = ctx->listInternal().size();

  // Push the count onto the stack.
  counts.push(count);
}

// We're exiting a list, two things to do again:
// 1. Print the closing square bracket.
// 2. Note the fact that we're leaving a list (remove a count).
void MyListener::exitList(demoParser::ListContext *ctx) {
  std::cout << ']';

  // Let's look at the top value and just make sure we aren't crazy.
  assert(*counts.top() == 0 && "We didn't pass all of the values?");

  // Free the new'd space and drop it from the stack.
  delete counts.top();
  counts.pop();
}

// We're entering an internal, the only thing we have to do is print a leaf. We cannot print the
// comma and space here because it's something we have to *after* printing the internal and the
// internal could be a list which won't have been printed yet because we haven't traversed down
// the tree to it. Truth be told, we could merge this into the exit function if we so chose, but
// for demonstration's sake, here it is.
void MyListener::enterListInternal(demoParser::ListInternalContext *ctx) {
  // So we're in a node with tokens that we care about (atoms/leaves) like ints/floats/strings
  // which means we should probably check if we parsed them at all. The easiest thing to do is to
  // just check if the context has one or not. If you call the function that would normally return
  // the token and it returns nullptr, then that option was not parsed.
  // Because we're not in control of where we're going, we only need to handle printing these
  // leaves. Lists will continue to be visited as part of the tree and the other functions will
  // handle printing those, as appropriate.
  // It would also be possible to have these visited as part of the visitTerminal, but the work is
  // exactly the same except you'd be using the parser's token enum to differentiate. Then we'd
  // only have to implement one of the listInternal state functions, the exit (for printing
  // commas).
  if (ctx->INT())
    std::cout << ctx->INT()->getText();
  else if (ctx->FLOAT())
    std::cout << ctx->FLOAT()->getText();
  else if (ctx->STR())
    std::cout << ctx->STR()->getText();
}

// Two things, once again:
// 1. Print the comma and space *if necessary*.
// 2. Note that we're leaving an internal (decrement the counter).
void MyListener::exitListInternal(demoParser::ListInternalContext *ctx) {
  // If the counter at the top is more than one, print the comma.
  if (*counts.top() > 1)
    std::cout << ", ";

  // Decrement the counter at the top. (--(*(counts.top()))).
  --*counts.top();
}
