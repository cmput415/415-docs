CMPUT 415 Student Submission License (Version 1.0)

Copyright 2018 `student name`

Unauthorized redistribution is forbidden in all circumstances. Use of this
software without explicit authorization from the author **or** CMPUT 415
Teaching Staff is prohibited.

This software was produced as a solution for an assignment in the course CMPUT
415 (Compiler Design) at the University of Alberta, Canada. This solution is
confidential and remains confidential after it is submitted for grading. The
course staff has the right to run plagiarism-detection tools on any code
developed under this license, even beyond the duration of the course.

Copying any part of this solution without including this copyright notice is
illegal.

If any portion of this software is included in a solution submitted for
grading at an educational institution, the submitter will be subject to the
sanctions for plagiarism at that institution.

This software cannot be publicly posted under any circumstances, whether by
the original student or by a third party. If this software is found in any
public website or public repository, the person finding it is kindly requested
to immediately report, including the URL or other repository locating
information, to the following email address:
[cmput415@ualberta.ca](mailto:cmput415@ualberta.ca).

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
