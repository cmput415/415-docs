
// Generated from /home/braedy/dev/lec/VCalcBase/grammar/VCalc.g4 by ANTLR 4.7.1

#pragma once


#include "antlr4-runtime.h"
#include "VCalcVisitor.h"


namespace vcalc {

/**
 * This class provides an empty implementation of VCalcVisitor, which can be
 * extended to create a visitor which only needs to handle a subset of the available methods.
 */
class  VCalcBaseVisitor : public VCalcVisitor {
public:

  virtual antlrcpp::Any visitFile(VCalcParser::FileContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExpr(VCalcParser::ExprContext *ctx) override {
    return visitChildren(ctx);
  }


};

}  // namespace vcalc
