
// Generated from /home/braedy/dev/lec/VCalcBase/grammar/VCalc.g4 by ANTLR 4.7.1

#pragma once


#include "antlr4-runtime.h"
#include "VCalcParser.h"


namespace vcalc {

/**
 * This class defines an abstract visitor for a parse tree
 * produced by VCalcParser.
 */
class  VCalcVisitor : public antlr4::tree::AbstractParseTreeVisitor {
public:

  /**
   * Visit parse trees produced by VCalcParser.
   */
    virtual antlrcpp::Any visitFile(VCalcParser::FileContext *context) = 0;

    virtual antlrcpp::Any visitExpr(VCalcParser::ExprContext *context) = 0;


};

}  // namespace vcalc
