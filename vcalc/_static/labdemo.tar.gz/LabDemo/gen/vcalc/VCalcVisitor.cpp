
// Generated from /home/braedy/dev/lec/VCalcBase/grammar/VCalc.g4 by ANTLR 4.7.1


#include "VCalcVisitor.h"


using namespace vcalc;

