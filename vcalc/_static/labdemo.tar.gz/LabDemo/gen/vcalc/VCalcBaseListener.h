
// Generated from /home/braedy/dev/lec/VCalcBase/grammar/VCalc.g4 by ANTLR 4.7.1

#pragma once


#include "antlr4-runtime.h"
#include "VCalcListener.h"


namespace vcalc {

/**
 * This class provides an empty implementation of VCalcListener,
 * which can be extended to create a listener which only needs to handle a subset
 * of the available methods.
 */
class  VCalcBaseListener : public VCalcListener {
public:

  virtual void enterFile(VCalcParser::FileContext * /*ctx*/) override { }
  virtual void exitFile(VCalcParser::FileContext * /*ctx*/) override { }

  virtual void enterExpr(VCalcParser::ExprContext * /*ctx*/) override { }
  virtual void exitExpr(VCalcParser::ExprContext * /*ctx*/) override { }


  virtual void enterEveryRule(antlr4::ParserRuleContext * /*ctx*/) override { }
  virtual void exitEveryRule(antlr4::ParserRuleContext * /*ctx*/) override { }
  virtual void visitTerminal(antlr4::tree::TerminalNode * /*node*/) override { }
  virtual void visitErrorNode(antlr4::tree::ErrorNode * /*node*/) override { }

};

}  // namespace vcalc
