
// Generated from /home/braedy/dev/lec/VCalcBase/grammar/VCalc.g4 by ANTLR 4.7.1

#pragma once


#include "antlr4-runtime.h"
#include "VCalcParser.h"


namespace vcalc {

/**
 * This interface defines an abstract listener for a parse tree produced by VCalcParser.
 */
class  VCalcListener : public antlr4::tree::ParseTreeListener {
public:

  virtual void enterFile(VCalcParser::FileContext *ctx) = 0;
  virtual void exitFile(VCalcParser::FileContext *ctx) = 0;

  virtual void enterExpr(VCalcParser::ExprContext *ctx) = 0;
  virtual void exitExpr(VCalcParser::ExprContext *ctx) = 0;


};

}  // namespace vcalc
