
// Generated from /home/braedy/dev/lec/VCalcBase/grammar/VCalc.g4 by ANTLR 4.7.1


#include "VCalcListener.h"
#include "VCalcVisitor.h"

#include "VCalcParser.h"


using namespace antlrcpp;
using namespace vcalc;
using namespace antlr4;

VCalcParser::VCalcParser(TokenStream *input) : Parser(input) {
  _interpreter = new atn::ParserATNSimulator(this, _atn, _decisionToDFA, _sharedContextCache);
}

VCalcParser::~VCalcParser() {
  delete _interpreter;
}

std::string VCalcParser::getGrammarFileName() const {
  return "VCalc.g4";
}

const std::vector<std::string>& VCalcParser::getRuleNames() const {
  return _ruleNames;
}

dfa::Vocabulary& VCalcParser::getVocabulary() const {
  return _vocabulary;
}


//----------------- FileContext ------------------------------------------------------------------

VCalcParser::FileContext::FileContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

VCalcParser::ExprContext* VCalcParser::FileContext::expr() {
  return getRuleContext<VCalcParser::ExprContext>(0);
}

tree::TerminalNode* VCalcParser::FileContext::EOF() {
  return getToken(VCalcParser::EOF, 0);
}


size_t VCalcParser::FileContext::getRuleIndex() const {
  return VCalcParser::RuleFile;
}

void VCalcParser::FileContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<VCalcListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterFile(this);
}

void VCalcParser::FileContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<VCalcListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitFile(this);
}


antlrcpp::Any VCalcParser::FileContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<VCalcVisitor*>(visitor))
    return parserVisitor->visitFile(this);
  else
    return visitor->visitChildren(this);
}

VCalcParser::FileContext* VCalcParser::file() {
  FileContext *_localctx = _tracker.createInstance<FileContext>(_ctx, getState());
  enterRule(_localctx, 0, VCalcParser::RuleFile);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(4);
    expr(0);
    setState(5);
    match(VCalcParser::EOF);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ExprContext ------------------------------------------------------------------

VCalcParser::ExprContext::ExprContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* VCalcParser::ExprContext::INT() {
  return getToken(VCalcParser::INT, 0);
}

std::vector<VCalcParser::ExprContext *> VCalcParser::ExprContext::expr() {
  return getRuleContexts<VCalcParser::ExprContext>();
}

VCalcParser::ExprContext* VCalcParser::ExprContext::expr(size_t i) {
  return getRuleContext<VCalcParser::ExprContext>(i);
}


size_t VCalcParser::ExprContext::getRuleIndex() const {
  return VCalcParser::RuleExpr;
}

void VCalcParser::ExprContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<VCalcListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterExpr(this);
}

void VCalcParser::ExprContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<VCalcListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitExpr(this);
}


antlrcpp::Any VCalcParser::ExprContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<VCalcVisitor*>(visitor))
    return parserVisitor->visitExpr(this);
  else
    return visitor->visitChildren(this);
}


VCalcParser::ExprContext* VCalcParser::expr() {
   return expr(0);
}

VCalcParser::ExprContext* VCalcParser::expr(int precedence) {
  ParserRuleContext *parentContext = _ctx;
  size_t parentState = getState();
  VCalcParser::ExprContext *_localctx = _tracker.createInstance<ExprContext>(_ctx, parentState);
  VCalcParser::ExprContext *previousContext = _localctx;
  size_t startState = 2;
  enterRecursionRule(_localctx, 2, VCalcParser::RuleExpr, precedence);

    

  auto onExit = finally([=] {
    unrollRecursionContexts(parentContext);
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    setState(8);
    match(VCalcParser::INT);
    _ctx->stop = _input->LT(-1);
    setState(15);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 0, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        if (!_parseListeners.empty())
          triggerExitRuleEvent();
        previousContext = _localctx;
        _localctx = _tracker.createInstance<ExprContext>(parentContext, parentState);
        pushNewRecursionContext(_localctx, startState, RuleExpr);
        setState(10);

        if (!(precpred(_ctx, 2))) throw FailedPredicateException(this, "precpred(_ctx, 2)");
        setState(11);
        match(VCalcParser::T__0);
        setState(12);
        expr(3); 
      }
      setState(17);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 0, _ctx);
    }
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }
  return _localctx;
}

bool VCalcParser::sempred(RuleContext *context, size_t ruleIndex, size_t predicateIndex) {
  switch (ruleIndex) {
    case 1: return exprSempred(dynamic_cast<ExprContext *>(context), predicateIndex);

  default:
    break;
  }
  return true;
}

bool VCalcParser::exprSempred(ExprContext *_localctx, size_t predicateIndex) {
  switch (predicateIndex) {
    case 0: return precpred(_ctx, 2);

  default:
    break;
  }
  return true;
}

// Static vars and initialization.
std::vector<dfa::DFA> VCalcParser::_decisionToDFA;
atn::PredictionContextCache VCalcParser::_sharedContextCache;

// We own the ATN which in turn owns the ATN states.
atn::ATN VCalcParser::_atn;
std::vector<uint16_t> VCalcParser::_serializedATN;

std::vector<std::string> VCalcParser::_ruleNames = {
  "file", "expr"
};

std::vector<std::string> VCalcParser::_literalNames = {
  "", "'+'"
};

std::vector<std::string> VCalcParser::_symbolicNames = {
  "", "", "INT", "WS"
};

dfa::Vocabulary VCalcParser::_vocabulary(_literalNames, _symbolicNames);

std::vector<std::string> VCalcParser::_tokenNames;

VCalcParser::Initializer::Initializer() {
	for (size_t i = 0; i < _symbolicNames.size(); ++i) {
		std::string name = _vocabulary.getLiteralName(i);
		if (name.empty()) {
			name = _vocabulary.getSymbolicName(i);
		}

		if (name.empty()) {
			_tokenNames.push_back("<INVALID>");
		} else {
      _tokenNames.push_back(name);
    }
	}

  _serializedATN = {
    0x3, 0x608b, 0xa72a, 0x8133, 0xb9ed, 0x417c, 0x3be7, 0x7786, 0x5964, 
    0x3, 0x5, 0x15, 0x4, 0x2, 0x9, 0x2, 0x4, 0x3, 0x9, 0x3, 0x3, 0x2, 0x3, 
    0x2, 0x3, 0x2, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 
    0x3, 0x7, 0x3, 0x10, 0xa, 0x3, 0xc, 0x3, 0xe, 0x3, 0x13, 0xb, 0x3, 0x3, 
    0x3, 0x2, 0x3, 0x4, 0x4, 0x2, 0x4, 0x2, 0x2, 0x2, 0x13, 0x2, 0x6, 0x3, 
    0x2, 0x2, 0x2, 0x4, 0x9, 0x3, 0x2, 0x2, 0x2, 0x6, 0x7, 0x5, 0x4, 0x3, 
    0x2, 0x7, 0x8, 0x7, 0x2, 0x2, 0x3, 0x8, 0x3, 0x3, 0x2, 0x2, 0x2, 0x9, 
    0xa, 0x8, 0x3, 0x1, 0x2, 0xa, 0xb, 0x7, 0x4, 0x2, 0x2, 0xb, 0x11, 0x3, 
    0x2, 0x2, 0x2, 0xc, 0xd, 0xc, 0x4, 0x2, 0x2, 0xd, 0xe, 0x7, 0x3, 0x2, 
    0x2, 0xe, 0x10, 0x5, 0x4, 0x3, 0x5, 0xf, 0xc, 0x3, 0x2, 0x2, 0x2, 0x10, 
    0x13, 0x3, 0x2, 0x2, 0x2, 0x11, 0xf, 0x3, 0x2, 0x2, 0x2, 0x11, 0x12, 
    0x3, 0x2, 0x2, 0x2, 0x12, 0x5, 0x3, 0x2, 0x2, 0x2, 0x13, 0x11, 0x3, 
    0x2, 0x2, 0x2, 0x3, 0x11, 
  };

  atn::ATNDeserializer deserializer;
  _atn = deserializer.deserialize(_serializedATN);

  size_t count = _atn.getNumberOfDecisions();
  _decisionToDFA.reserve(count);
  for (size_t i = 0; i < count; i++) { 
    _decisionToDFA.emplace_back(_atn.getDecisionState(i), i);
  }
}

VCalcParser::Initializer VCalcParser::_init;
