#ifndef VCALCBASE_CODEGENERATOR_H
#define VCALCBASE_CODEGENERATOR_H

#include "VCalcBaseVisitor.h"

#include "llvm/IR/IRBuilder.h"
#include "llvm/IR/LLVMContext.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/Verifier.h"
#include "llvm/Support/raw_os_ostream.h"

#include <ostream>

namespace vcalc {

class CodeGenerator : public VCalcBaseVisitor {
public:
  CodeGenerator() : VCalcBaseVisitor(), globalCtx(), ir(globalCtx), mod("vcalc", globalCtx) { }

  antlrcpp::Any visitFile(VCalcParser::FileContext *ctx) override;
  antlrcpp::Any visitExpr(VCalcParser::ExprContext *ctx) override;

  void dump(std::ostream &os) {
    llvm::raw_os_ostream ros(os);
    llvm::raw_os_ostream llErr(std::cerr);

    llvm::verifyModule(mod, &llErr);
    mod.print(ros, nullptr);
  }

private:
  // LLVM construction tools.
  llvm::LLVMContext globalCtx;
  llvm::IRBuilder<> ir;
  llvm::Module mod;
};

}

#endif //VCALCBASE_CODEGENERATOR_H
