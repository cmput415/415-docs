#include "codegenerator/CodeGenerator.h"

#include "llvm/IR/BasicBlock.h"
#include "llvm/IR/Constants.h"
#include "llvm/IR/DerivedTypes.h"
#include "llvm/IR/TypeBuilder.h"
#include "llvm/Support/Casting.h"

#include <string>

namespace vcalc {

antlrcpp::Any CodeGenerator::visitFile(VCalcParser::FileContext *ctx) {
  llvm::FunctionType *mainTy =
      llvm::TypeBuilder<int(int, char**), false>::get(globalCtx);

  auto main = llvm::cast<llvm::Function>(mod.getOrInsertFunction("main", mainTy));
  llvm::BasicBlock *entry = llvm::BasicBlock::Create(globalCtx, "entry", main);
  ir.SetInsertPoint(entry);

  llvm::Value *expr = visit(ctx->expr());
  llvm::Value *loaded = ir.CreateLoad(expr);
  ir.CreateRet(loaded);

  return nullptr;
}

antlrcpp::Any CodeGenerator::visitExpr(VCalcParser::ExprContext *ctx) {
  llvm::Type *intTy = llvm::TypeBuilder<llvm::types::i<32>, true>::get(globalCtx);

  if (ctx->INT()) {
    int value = std::stoi(ctx->INT()->getText());
    uint64_t trueValue = static_cast<uint64_t>(static_cast<int64_t>(value));
    llvm::Value *val1 = llvm::ConstantInt::get(intTy, trueValue, true);

    llvm::Value *ptr = ir.CreateAlloca(intTy);
    ir.CreateStore(val1, ptr);
    return ptr;
  }

  llvm::Value *lhsP = visit(ctx->expr(0));
  llvm::Value *rhsP = visit(ctx->expr(1));
  llvm::Value *lhs = ir.CreateLoad(lhsP);
  llvm::Value *rhs = ir.CreateLoad(rhsP);

  llvm::Value *addition = ir.CreateAdd(lhs, rhs);

  llvm::Value *resP = ir.CreateAlloca(intTy);
  ir.CreateStore(addition, resP);

  return resP;
}

}
