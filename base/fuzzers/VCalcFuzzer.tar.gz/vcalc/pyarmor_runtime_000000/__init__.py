# Pyarmor 8.5.9 (trial), 000000, 2024-09-20T17:24:00.538050
from .pyarmor_runtime import __pyarmor__
